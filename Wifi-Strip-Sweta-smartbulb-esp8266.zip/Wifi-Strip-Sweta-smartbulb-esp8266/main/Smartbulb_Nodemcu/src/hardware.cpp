#include "hardware.h"
#include "cloud.h"


extern struct led_def led;

/**
 * set RGB color
 * args: void
 * return: void
 */
void RGB_color(uint8_t red_light_value, uint8_t green_light_value, uint8_t blue_light_value) {
  red_light_value = ((led.r/1023.0)*led.bright);
  green_light_value = ((led.g/1023.0)*led.bright);
  blue_light_value  = ((led.b/1023.0)*led.bright);
  analogWrite(Red, red_light_value);
  analogWrite(Green, green_light_value);
  analogWrite(Blue, blue_light_value);
}

/**
 * init_gpio_pins: initialize GPIO pins
 * args: void
 * return: void
 */
void init_gpio_pins() {
  pinMode(Red, OUTPUT);
  pinMode(Green, OUTPUT);
  pinMode(Blue, OUTPUT);
  pinMode(json_interrupt, OUTPUT);
}

/**
 * args: void
 * returns:
 *  !0 for error
 *  0 for success
 */
int init_hardware() { 
  // Initialize GPIO Pins
  init_gpio_pins();

  int ret = nv_mount();
  if (ret != succes) {
    // cannot proceed ahead, return with failure
    PRINTR("memory_error");
    return ret;
  }
  return ret;
}