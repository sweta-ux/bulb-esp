#include "definitions.h"
#include "scheduler.h"
#include "RTClib.h"
#include "cloud.h"

extern struct led_def led;

RTC_DS3231 rtc;
DateTime now;
int Hour;
int Minute;

/**
 * init_rtc:- if rtc not initialise do nothing and if initialised set rtc time
 * args: void
 * ret: int
 */
int init_rtc(void) {
  if (!rtc.begin()) {
    PRINTR("Couldn't find RTC");
    PRINTR("Couldn't find RTC");
    // It stuck in this loop but we can toggle relays with out RTC
    //while (1)
      return fail;
  }
  if (rtc.lostPower()) {
    PRINTR("RTC lost power, lets set the time!");
    // This line sets the RTC with an explicit date &amp; time, for example to set
     //rtc.adjust(DateTime(2021, 03, 16, 16, 34, 10));
    return fail;
  }
  return succes;
}

/**
 * check_rtc_time - set time
 * args: void
*/
void check_rtc_time() {
  DateTime now = rtc.now();
  char hr[] = "hh";
  String _hr = (now.toString(hr));
  Hour = _hr.toInt();
  char mn[] = "mm";
  String _mn = (now.toString(mn));
  Minute = _mn.toInt();
}

void led_on_with_scheduler() {
 // for (;;) {
  led_on_or_off_with_rtc(&led);
  DELAY_1000;
  //}
}

/**
 * led_on_or_off - compare start hour and minute toggle relays
 * args: struct relay_def
 * ret: void
*/
void led_on_or_off_with_rtc(struct led_def *r) {
  if (r->scheduler_enabled) {
    if (Hour < r->r_start_hour || Hour > r->r_end_hour) {
      RGB_color(r->r=0,r->g=0,r->b=0);
      Serial.printf("Hours different:  (Hour: %u)(start_hour: %u)(end_hour: %u)\n", Hour, r->r_start_hour, r->r_end_hour);
      return;
    }

    if (Hour > r->r_start_hour && Hour < r->r_end_hour) {
      RGB_color(r->r,r->g,r->b);
      PRINTR("hours greater than stat hr and less then end hr");
      return;
    }

    /* Lets check if the hour to start and end is same or not */
    if (Hour == r->r_start_hour && Hour == r->r_end_hour) {
      if (Minute < r->r_start_min || Minute > r->r_end_min) {
        RGB_color(r->r=0,r->g=0,r->b=0);
        Serial.printf("Hours same:  (Hour: %u)(start_hour: %u)(end_hour: %u)\n", Hour, r->r_start_hour, r->r_end_hour);
        return;
      }
      if (r->r_start_min == r->r_end_min && Minute == r->r_start_min) {
        RGB_color(r->r=0,r->g=0,r->b=0);
        PRINTR("minutes same");
        return;
      }
      if (Minute >= r->r_start_min && Minute < r->r_end_min) {
        RGB_color(r->r,r->g,r->b);
        PRINTR("minute greater then str min and less then end min: ");
        return;
      }

      /* Otherwise Minute is actually equal to or more than on_end_min */
      RGB_color(r->r=0,r->g=0,r->b=0);
      PRINTR("nothing");
      return;
    }

    if (Hour == r->r_start_hour && Hour < r->r_end_hour) {
      if (Minute >= r->r_start_min) {
        RGB_color(r->r,r->g,r->b);
        PRINTR("Hour is equals to strt hour and less than end hour");
        return;
      } else {
        RGB_color(r->r=0,r->g=0,r->b=0);
        PRINTR("Setting it low");
        return;
      }
    }

    if (Hour > r->r_start_hour && Hour == r->r_end_hour) {
      if (Minute < r->r_end_min) {
        RGB_color(r->r,r->g,r->b);
        PRINTR("Hour is greater than strt hour and equals to end hour");
        return;
      } else {
        RGB_color(r->r=0,r->g=0,r->b=0);
        PRINTR("Setting it low");
        return;
      }
    }
  }
}