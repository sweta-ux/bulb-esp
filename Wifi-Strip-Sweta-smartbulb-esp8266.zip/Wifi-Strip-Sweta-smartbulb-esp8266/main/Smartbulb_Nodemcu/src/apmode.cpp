#include "apmode.h"

IPAddress local_ip(192, 168, 1, 1);
IPAddress gateway(192, 168, 1, 1);
IPAddress subnet(255, 255, 255, 0);
  
/**
 * ap_mode - enable ap_mode when SSID/Pass is not available
 * args: void
 * return: void
 */
void ap_mode() { 
  //const char* Device_Name = "Smart-Strip";
  WiFi.softAP(device_name);
  DELAY_1000;
  WiFi.disconnect();
  if (WiFi.isConnected())
    PRINTR("Wifi is connected");
  WiFi.softAPConfig(local_ip, gateway, subnet);
  if((WiFi.status() != WL_CONNECTED)) {
    PRINTR("not connecting");  
    web_server();
 }
}  
