/******************************************************************************
 * Copyright 2020 IndiaSells
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *****************************************************************************/
#ifndef _HARDWARE_H
#define _HARDWARE_H

#include "definitions.h"
#include "nv.h"

#define Red 14
#define Green 12
#define Blue 13
#define json_interrupt 21
#define reset_interrupt 12

/* declaration of the function */
void RGB_color(uint8_t, uint8_t, uint8_t);
void init_gpio_pins();
int init_hardware();

#endif
