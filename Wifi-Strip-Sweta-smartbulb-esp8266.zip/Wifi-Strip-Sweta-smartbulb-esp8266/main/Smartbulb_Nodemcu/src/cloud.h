/******************************************************************************
 * Copyright 2020 IndiaSells
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *****************************************************************************/
#ifndef CLOUD_H
#define CLOUD_H

//#include <WiFiClientSecure.h>
#include "WiFiClientSecureBearSSL.h"
#include "nv.h"
#include "definitions.h"
#include "hardware.h"

struct led_def{
  uint8_t r;
  uint8_t g;
  uint8_t b;
  uint8_t bright;
  uint8_t r_start_hour;
  uint8_t r_start_min;
  uint8_t r_end_hour;
  uint8_t r_end_min;
  uint8_t scheduler_enabled;
  String unique_cmd;
};

/* declaration of the function */
void wifi_start(struct cloud_def *);
int check_wifi(void);
String getJwt();
bool publish_telemetry(String );
void mqtt_connect(bool);
void connect(void);
void start_mqtt(void);
void setup_Certificate();
int setup_iot_cloud(struct cloud_def *);
void check_mqtt_reconnect();
void receive_from_server();
void dump_rgb(struct led_def *);
void update_relay(int r, uint8_t pin);
void send_to_server();
void message_received(String & , String &);
void create_response_json();
void periodic_response_send();
void send_json();
void publish_json();
int network_error_log(void);
int mqtt_error_log(void);

#endif