#include <ArduinoJson.h>
#include "nv.h"
#include "definitions.h"

File file;
String ssid;
String pass;
String deviceid;
String privatekey;
String registryid;

/**
 * nv_mout-> checking nv is ok or not
 * args: void
 * returns:
 *  !0 for error
 *  0 for success
 */
int nv_mount(void) { 
  if (!SPIFFS.begin()) { 
    return fail;
  }
  return succes;
}

/**
 * nv_write - write data in nv file
 * args: fs::FS &fs, const char * path, const char * message
 * returns: int
 */
int nv_write(fs::FS &fs, const char * path, const char * message) {
  Serial.printf("Writing file: %s\r\n", path);
  File file = fs.open(path, "w"); 
  if (!file) {
    PRINTR("There was an error opening the file for writing");
   return fail;
  }
  
  if (file.print(message)) {
    PRINTR("File was written");
  } else {
    PRINTR("File write failed");
    return fail;
  }
  file.close();
  return succes;
}

/**
 * read_file-> reading data fromt he file in the nv
 * args: fs::FS &fs, const char * path
 * returns: String
 */
String read_file(fs::FS &fs, const char * path) { 
  String fileContent;
  #if DEBUG == 1
    Serial.printf("Reading file: %s\r\n", path);
  #endif
  file = fs.open(path, "r");
  if(!file){
   PRINTR("There was an error opening the file for writing");
   return no_data_in_nv;
  }
  PRINTR("- read from file:");
  PRINTR(path);
  while (file.available()) { 
    fileContent+=String((char)file.read());
  }
  #if DEBUG==1
    Serial.println(fileContent);
  #endif
  return fileContent;
}

/**
 * validate_nv - validate data which is read from nv
 * args: void
 * returns: int
 */
int validate_nv(struct cloud_def *_config) {
  String nv_data = read_file(SPIFFS, DATAFILE);
  StaticJsonBuffer<500> jsonBuffer;
  JsonObject& root = jsonBuffer.parseObject(nv_data);
  if(!root.success()){
    PRINTS("NOT PARSING");
    return fail;
  }

  ssid = (const char *)root["ssid"];
  pass = (const char *)root["pass"];
  deviceid = (const char *)root["dev"];
  registryid = (const char *)root["reg_id"];
  privatekey = (const char *)root["private_key"];

  _config->wifi_ssid = ssid.c_str();
  _config->wifi_pass = pass.c_str();
  _config->cloud_project_id = PROJECTID;
  _config->cloud_location = LOCATION;
  _config->cloud_device_id = deviceid.c_str();
  _config->cloud_private_key = privatekey.c_str();
  _config->cloud_registry_id = registryid.c_str();
  return succes;
}

/**
 * clear_nv - formatted SPIFFS
 * args: void
 * return: int
*/
int  clear_nv(void) {
bool formatted = SPIFFS.format();
  if ( formatted ) {
    PRINTR("SPIFFS formatted successfully");
  } else {
    PRINTR("Error formatting");
    return fail;
  }
  return succes;
}