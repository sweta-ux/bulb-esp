/******************************************************************************
 * Copyright 2020 IndiaSells
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *****************************************************************************/
#ifndef DEFINITION_H
#define DEFINITION_H

#include <stdint.h>

/* Debugging switches and macros
 Switch debug output on and off by 1 or 0*/
#define DEBUG 1

#if DEBUG
#define PRINTS(...) Serial.print(__VA_ARGS__)
#define PRINTR(...) Serial.println(__VA_ARGS__)
#else
#define PRINTS(s)
#define PRINTR(s)
#endif

#define DELAY_100 delay(100)
#define DELAY_300 delay(300)
#define DELAY_2000 delay(2000)
#define DELAY_1000 delay(1000)
#define DELAY_5000 delay(5000)
#define DELAY_10000 delay(10000)
#define DELAY_X delay(1000)

#define succes 0
#define fail 1

#define no_data_in_nv "E03" /* NO DATA */
#define device_name "smart_bulb"
#define max_sending_time 360000   /* SEDNING JSON TIME */

#define DATAFILE "/data.txt"

#define PROJECTID "smart-bulb-001";
#define LOCATION "us-central1";

/**
 * cloud - define the structure for cloud configuration
 */
struct cloud_def {
  const char *wifi_ssid;
  const char *wifi_pass;
  const char *cloud_project_id;
  const char *cloud_location;
  const char *cloud_device_id;
  const char *cloud_private_key;
  const char *cloud_registry_id;
};

#endif