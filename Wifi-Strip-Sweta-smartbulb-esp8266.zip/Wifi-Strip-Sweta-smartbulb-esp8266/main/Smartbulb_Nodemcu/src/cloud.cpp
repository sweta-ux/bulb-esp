#include <Client.h>
#include <MQTT.h>
#include <iotmqtt.h>
#include <CloudCore.h>
#include <ArduinoJson.h>
#include "cloud.h"
#include "ciot_config.h"

/* declaring object of the class */
iotdevice *device;
iotmqtt *mqtt;
MQTTClient *mqttClient;
static BearSSL::WiFiClientSecure netClient;
static BearSSL::X509List certList;

/* Extern struct from other file*/
extern struct cloud_def _config;

bool interrupt_flag = false;
boolean skip;
String payload;
const char *cloud_device_id;

struct led_def led;

/**
 * start_wifi-> initialising wifi
 * args: void
 * returns: int
 */
void wifi_start(struct cloud_def *_config) {
  if (WiFi.status() != WL_CONNECTED) {
    PRINTR(_config[0].wifi_ssid);
    PRINTR(_config[0].wifi_pass);
    WiFi.begin( _config[0].wifi_ssid, _config[0].wifi_pass);
    DELAY_10000;
    PRINTS("IP Address: ");
    Serial.println(WiFi.localIP());
    configTime(0, 0, "pool.ntp.org", "time.nist.gov");
    PRINTR("Waiting on time sync...");
    while (time(nullptr) < 60000) {
      //Serial.println(time(nullptr));
      delay(10);
    }
  }  
}

/**
 * check_wifi - check wifi connection
 * args: void
 * return: int
 */
int check_wifi(void) {
  WiFi.mode(WIFI_STA);
  delay(1000);
  uint8_t i = 0;
  PRINTR(WiFi.status());
  while((WiFi.status() != WL_CONNECTED) && (i <= 20)) {
    PRINTS(".");
    if ((++i % 20) == 0) {
      return fail;     
    }
  }
  return succes;
}

/**
 * getjwt-> getting jwt as in string 
 * args: null
 * returns: string
 */
String getJwt() {    
/* Time (seconds) to expire token += 20 minutes for drift*/
/* Maximum 24H (3600*24) */
  ESP.wdtDisable();
  const int jwt_exp_secs = 3600*24;
  unsigned long iat = time(nullptr);
  Serial.println(iat);
  PRINTR("Refreshing JWT");
  String jwt = device->createJWT(iat, jwt_exp_secs);
  ESP.wdtEnable(0);
  return jwt;
}

/**
 *publish_Telemetry-> method fro sending data
 * args: String data
 * returns: bool
 */
bool publish_telemetry(String data) {
  return mqtt->publishTelemetry(data);
}

/**
 * mqtt_connect-> connect with mqtt 
 * args: bool skip
 * returns: int
 */
void mqtt_connect(bool skip) {
  int __backoff__ = 1000; // current backoff, milliseconds
  static const int __factor__ = 2.5f;
  static const int __minbackoff__ = 1000; // minimum backoff, ms
  static const int __max_backoff__ = 60000; // maximum backoff, ms
  static const int __jitter__ = 500; // max random jitter, ms
  PRINTR("Connecting...");
  bool keepgoing = true;
  if (keepgoing) {
    bool result =mqttClient->connect( device->getClientId().c_str(), "unused", getJwt().c_str(), skip);
    if (mqttClient->lastError() != LWMQTT_SUCCESS && result) {
    network_error_log();
    mqtt_error_log();
      if (__backoff__ < __minbackoff__) {
      __backoff__ = __minbackoff__;
    }
    __backoff__ = (__backoff__ * __factor__) + random(__jitter__);
      if (__backoff__ > __max_backoff__) {
    __backoff__ = __max_backoff__;
    }
    // Clean up the client
    mqttClient->disconnect();
    skip = false;
    Serial.println("Delaying " + String(__backoff__) + "ms");
    delay(__backoff__);
    keepgoing = true;
  } else {
      PRINTR(mqttClient->connected() ? "connected" : "not connected");
      if (!mqttClient->connected()) {
        PRINTR("Retrying to connect");
        mqttClient->disconnect();
        skip = false;
        keepgoing = true;
        PRINTR("Waiting 60 seconds");
        delay(__max_backoff__);
      } else {
        // We're now connected
        PRINTR("\nLibrary connected!");
        keepgoing = false;
        __backoff__ = __minbackoff__;
      }
    }
  }
  mqttClient->subscribe(device->getCommandsTopic(), 0);
  publish_telemetry("connected");
}

/**
 * connect-> connect with wifi and mqtt
 * args: void
 * ret: int
 */
void connect() {
  int ret = check_wifi();
  if (ret != succes) {
    wifi_start(&_config);
  }
  DELAY_100;
  mqtt_connect(skip);
}

/**
 * start_mqtt-> initialized mqtt 
 * args: void
 * ret: int
 */
void start_mqtt() {
  boolean enabled;
  boolean useLts = true;
  enabled = useLts;
  mqttClient->begin(enabled ? MQTT_HOST_LTS : MQTT_HOST,MQTT_PORT, netClient);
}


/**
 * 
 */
void setup_Certificate () {
  certList.append(primary_ca);
  certList.append(backup_ca);
  netClient.setTrustAnchors(&certList);
}

/**
 * 
 */
int setup_iot_cloud(struct cloud_def *_config)
{
  device = new iotdevice(_config->cloud_project_id, _config->cloud_location, _config->cloud_registry_id, _config->cloud_device_id, _config->cloud_private_key);
  // ESP8266 WiFi secure initialization
  setup_Certificate();
  cloud_device_id = _config->cloud_device_id;
  mqttClient = new MQTTClient(512);
  mqttClient->setOptions(180, true, 1000); // keepAlive, cleanSession, timeout
  mqtt = new iotmqtt(mqttClient, &netClient, device);
  mqtt->setUseLts(true);
  start_mqtt();
}

/**
 * reconnect-> reconnect with wifi and mqtt
 * args: void
 * ret: void
 */
void check_mqtt_reconnect() {
  mqtt->loop();
  DELAY_100;  
  if (!mqttClient->connected()) {
    PRINTR("mqtt_disconnect");
    connect();
  }
}

/**
 * 
 */
void receive_from_server() {
  mqttClient->onMessage(message_received);
  DELAY_1000;
}

/**
 * dump_rgb - print RGB value on serial
 * args: struct
 * ret: void
 */
void dump_rgb(struct led_def *rl) {
  PRINTR("rgb_status:");
    #if DEBUG == 1
      Serial.printf("(%u)(%u)(%u)(%u)(%u)(%u)(%u)\n",rl->r,rl->g,rl->b,rl->r_start_hour, rl->r_start_min,
                   rl->r_end_hour, rl->r_end_min);
    #endif
}

/**
 * message_received - function fore receing the message from the mqtt
 * args: string topic, string payload
 * return: void
 */
void message_received(String &topic, String &payload){
  PRINTR("incoming: " + topic + " - " + payload);
  StaticJsonBuffer<500> jsonBuffer;
  JsonObject& root = jsonBuffer.parseObject(payload);
  if (!root.success()) {
    String cmd_status = String("{\"device_id\":\"") + cloud_device_id + 
                  String("\",\"status\":\"") + "2" +\
                  String("\",\"msg\":\"") + "invalid cmd" +\
                  String("\"}");
    publish_telemetry(cmd_status);
    PRINTR(cmd_status);
  }
  int cmd = root["cmd"];
  String url = root["uniquestr"];
  uint8_t red = root["r"];
  uint8_t green = root["g"];
  uint8_t blue = root["b"];
  uint8_t value = root["brightness"];
  uint8_t strt_hour = root["strt_hr"];
  uint8_t strt_min = root["strt_mn"];
  uint8_t end_hour = root["end_hr"];
  uint8_t end_min = root["end_mn"];
  uint8_t is_scheduler = root["scheduler_on"];
  
  //led = {red, green , blue, url};
  led.r = red;
  led.g = green;
  led.b = blue;
  led.bright = value;
  led.r_start_hour = strt_hour;
  led.r_start_min = strt_min;
  led.r_end_hour = end_hour;
  led.r_end_min = end_min;
  led.unique_cmd = url.c_str();
  led.scheduler_enabled = is_scheduler;


  PRINTR(cmd);
  PRINTR(url);
  dump_rgb(&led);
            
  switch(cmd) {  
    case 1:
      PRINTR("update ota");
      break;
    case 2:    
      PRINTR("update RGB colour");
      dump_rgb(&led);
      RGB_color(led.r, led.g, led.b);

      // create interrupt for sending rgb values. 
      digitalWrite(json_interrupt, LOW);
      DELAY_100;
      digitalWrite(json_interrupt, HIGH);
      DELAY_100;
      break;
    case 3:    
      PRINTR("update RGB colour using scheduler");
      break;
    case 4:
      PRINTR("Clear nv");
      clear_nv();
  }
}

/**
 * send_to_server - creating the task for publish json
 * args: void *pvparameters
 * return: void
 */
void send_to_server() {
  periodic_response_send();
  DELAY_300;
}

/*
 * create_response_json: send json periodically and non periodically
 * args: bool
 * return: void
 */
void create_response_json(bool is_periodic) {
  payload = String("{\"device_id\":\"") + cloud_device_id +\
            String("\",\"timestamp\":\"") + time(nullptr) +\
            String("\",\"r\":\"") + String(led.r) +\
            String("\",\"g\":\"") + String(led.g) +\
            String("\",\"b\":\"") + String(led.b);
  if (!is_periodic)
    payload += String("\",\"uniquestr\":\"") + String(led.unique_cmd);
  else
    payload += String("\",\"status\":\"") + "3"+\
              String("\",\"uniquestr\":\"");
  payload += String("\"}");
  PRINTR(payload);
}

/**
 * data_string - publish the json periodically
 * args: void
 * return: void
 */
unsigned long lastMillis = 0;
void periodic_response_send() {
  //PRINTR("In periodic_response_send");
  unsigned long currentmillis = millis();
  if ((currentmillis - lastMillis > max_sending_time) || interrupt_flag){
    lastMillis = currentmillis;
    publish_json();
  }
}

/**
 * send_json - changing the interrupt_flag in bool
 * args: void
 * return: void
 */
void send_json() {
  interrupt_flag = true;
}

/**
 * publish_json - publish json string when recieve interrupt_flag as true and at a preiodic time 
 * args: void
 * return: void
 */
void publish_json(){
  PRINTR("In publish_json");
  if (interrupt_flag) {
    create_response_json(false);
    interrupt_flag = false;
  } else {
    create_response_json(true);
  }

  publish_telemetry(payload);
  lastMillis = millis();  
}

/**
 * log_error-> returning mqtt error while connecting with mqtt
 * args: void
 * ret: int
 */
int network_error_log(void) {
  int error2 = mqttClient->lastError();
  if (error2 == 0) {
    PRINTS("LWMQTT_SUCCESS");
  } else if (error2 == -1) {
    PRINTS("LWMQTT_BUFFER_TOO_SHORT");
  }else if (error2 == -2) {
    PRINTS("LWMQTT_VARNUM_OVERFLOW"); 
  } else if (error2 == -3) {
    PRINTS("LWMQTT_NETWORK_FAILED_CONNECT");
  }
  return error2;
}

/**
 * log_return_code-> returning mqtt error while connecting with mqtt
 * args: void
 * ret: int
 */
int mqtt_error_log(void) {
  int error1 = mqttClient->returnCode();
  if (error1 == 0) {
    PRINTS("LWMQTT_CONNECTION_ACCEPTED");
  } else if (error1 == -1) {
    PRINTS("LWMQTT_UNACCEPTABLE_PROTOCOL");
  } else if (error1 == -2) {
    PRINTS("LWMQTT_IDENTIFIER_REJECTED");
  } else if (error1 == -3) {
    PRINTS("LWMQTT_SERVER_UNAVAILABLE");
  } 
  return error1;
}