/******************************************************************************
 * Copyright 2020 IndiaSells
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *****************************************************************************/
/* Defining The Libraries */
#include "apmode.h"
#include "cloud.h"
#include "scheduler.h"
#include <EEPROM.h>

struct cloud_def _config = {0};

/**
 * setup - 
 */
void setup()
{
  Serial.begin(115200);
  EEPROM.begin(512);
  int b = EEPROM.read(0);
  PRINTR("\n");
  Serial.println(b);
  PRINTR("\n");
  if (b >= 5) {
    clear_nv();
    EEPROM.write(0, 0);
    EEPROM.commit();
    delay(1000);
  } else {
    EEPROM.write(0, ++b);
    EEPROM.commit();
    delay(1000);
  }

  int counter = 0;
  int ret;
  ret = init_hardware();
  if (ret != succes) {
    while (1) {
      DELAY_10000;
    }
  }
  
  do {
    ret = validate_nv(&_config);
    if (ret != succes) {
      ap_mode();
      //continue;
    }

    // wifi Initialization
    // Not checked for error as global variable would
    // set against this.
    do {
      wifi_start(&_config);
      ret = check_wifi();
      if (ret == succes) {
        PRINTR("check wifi succeeded\n");
        break;
      }
      counter++;
    } while (counter < 10);
  
    if (ret == succes)
      break;

    if (counter >= 10) {
      counter = 0;
    }
  } while(1);

  ret = init_rtc();
  if (ret != succes) {
    //if RTC is not working,seprate light will have to operate from server. in this case only scheduler will stuck 
   // while(1);
   DELAY_1000;
  }
  setup_iot_cloud(&_config);
}

/**
 * 
 */
void loop() {
  // resetting EEPROM restart counter
  EEPROM.write(0, 0);
  EEPROM.commit();
  DELAY_300;

  check_rtc_time();
  DELAY_100;
  check_mqtt_reconnect();
  DELAY_100;
  receive_from_server();
  DELAY_100;
  led_on_with_scheduler();
  DELAY_100;
  send_to_server();
  
}